-- ================================
-- MetaCube Main Script
-- Version: 1.0.0
-- ================================

-- 設定ファイルを読み込み
local config = require("config")

-- 必要なライブラリをロード
local timeline = require("functions.timeline")
local follow = require("functions.follow")
local active = require("functions.active")
local utils = require("functions.utils")

-- ================================
-- グローバル変数
-- ================================
local daily_counts = {
    likes = 0,
    follows = 0,
    unfollows = 0,
}

local start_time = os.time()
local errors_count = 0

-- ================================
-- メイン処理
-- ================================
function main()
    -- 初期化
    utils.log("info", "MetaCube Starting...")
    utils.log("info", "Plan: " .. config.plan)

    -- Instagramアプリを起動
    if not launchInstagram() then
        utils.log("error", "Failed to launch Instagram")
        return
    end

    -- プランに応じた処理を実行
    while true do
        -- 時間チェック
        if not isActiveHour() then
            utils.log("info", "Outside active hours. Sleeping...")
            sleep(3600) -- 1時間待機
            goto continue
        end

        -- 日付が変わったらカウントリセット
        checkDailyReset()

        -- プラン別の処理
        if config.plan == "basic" then
            executeBasicPlan()
        elseif config.plan == "standard" then
            executeStandardPlan()
        elseif config.plan == "premium" then
            executePremiumPlan()
        else
            utils.log("error", "Invalid plan: " .. config.plan)
            break
        end

        -- エラーチェック
        if errors_count >= config.safety.stop_on_errors then
            utils.log("error", "Too many errors. Stopping...")
            break
        end

        ::continue::
    end
end

-- ================================
-- プラン別処理
-- ================================

-- ベーシックプラン: タイムラインいいねのみ
function executeBasicPlan()
    utils.log("info", "Executing Basic Plan")

    -- デイリーリミットチェック
    if daily_counts.likes >= config.settings.daily_limits.likes then
        utils.log("info", "Daily like limit reached")
        sleep(3600) -- 1時間待機
        return
    end

    -- タイムラインいいね実行
    local success = timeline.performLike()

    if success then
        daily_counts.likes = daily_counts.likes + 1
        utils.log("info", "Likes today: " .. daily_counts.likes)
    else
        errors_count = errors_count + 1
    end

    -- インターバル
    local interval = utils.randomBetween(
        config.settings.intervals.like_min,
        config.settings.intervals.like_max
    )
    sleep(interval)
end

-- スタンダードプラン: いいね＋フォロー/アンフォロー
function executeStandardPlan()
    utils.log("info", "Executing Standard Plan")

    -- アクション選択（ランダム）
    local action = math.random(1, 100)

    if action <= 60 then
        -- 60%: いいね
        if daily_counts.likes < config.settings.daily_limits.likes then
            if timeline.performLike() then
                daily_counts.likes = daily_counts.likes + 1
            else
                errors_count = errors_count + 1
            end
        end
    elseif action <= 80 then
        -- 20%: フォロー
        if daily_counts.follows < config.settings.daily_limits.follows then
            if follow.performFollow() then
                daily_counts.follows = daily_counts.follows + 1
            else
                errors_count = errors_count + 1
            end
        end
    else
        -- 20%: アンフォロー
        if daily_counts.unfollows < config.settings.daily_limits.unfollows then
            if follow.performUnfollow() then
                daily_counts.unfollows = daily_counts.unfollows + 1
            else
                errors_count = errors_count + 1
            end
        end
    end

    -- ステータス表示
    utils.log("info", string.format(
        "Today: Likes=%d, Follows=%d, Unfollows=%d",
        daily_counts.likes,
        daily_counts.follows,
        daily_counts.unfollows
    ))

    -- インターバル
    local interval = utils.randomBetween(
        config.settings.intervals.like_min,
        config.settings.intervals.follow_max
    )
    sleep(interval)
end

-- プレミアムプラン: 全機能（アクティブユーザーいいね含む）
function executePremiumPlan()
    utils.log("info", "Executing Premium Plan")

    -- アクション選択（高度な戦略）
    local action = math.random(1, 100)

    if action <= 40 then
        -- 40%: タイムラインいいね
        if timeline.performLike() then
            daily_counts.likes = daily_counts.likes + 1
        else
            errors_count = errors_count + 1
        end
    elseif action <= 60 then
        -- 20%: アクティブユーザーいいね
        local hashtag = config.targets.hashtags[math.random(#config.targets.hashtags)]
        if active.likeByHashtag(hashtag) then
            daily_counts.likes = daily_counts.likes + 1
        else
            errors_count = errors_count + 1
        end
    elseif action <= 75 then
        -- 15%: ターゲットフォロー
        if active.followTargetUsers() then
            daily_counts.follows = daily_counts.follows + 1
        else
            errors_count = errors_count + 1
        end
    elseif action <= 90 then
        -- 15%: スマートアンフォロー
        if follow.smartUnfollow() then
            daily_counts.unfollows = daily_counts.unfollows + 1
        else
            errors_count = errors_count + 1
        end
    else
        -- 10%: 探索タブ巡回
        active.exploreAndEngage()
    end

    -- ステータス表示
    utils.log("info", string.format(
        "Premium Stats: L=%d, F=%d, U=%d, Errors=%d",
        daily_counts.likes,
        daily_counts.follows,
        daily_counts.unfollows,
        errors_count
    ))

    -- インターバル（よりランダムに）
    local interval = utils.randomBetween(
        config.settings.intervals.like_min,
        config.settings.intervals.follow_max
    )
    if config.safety.randomize then
        interval = interval + math.random(-5, 10)
    end
    sleep(interval)
end

-- ================================
-- ヘルパー関数
-- ================================

-- Instagramアプリを起動
function launchInstagram()
    utils.log("info", "Launching Instagram...")
    appRun("com.instagram.ios")
    sleep(5)

    -- ホーム画面に戻っているか確認
    if not utils.findElement("feed_tab") then
        utils.log("warning", "Not on home feed, attempting to navigate...")
        tap(50, 800) -- ホームタブをタップ
        sleep(2)
    end

    return true
end

-- アクティブ時間かチェック
function isActiveHour()
    local hour = tonumber(os.date("%H"))
    return hour >= config.settings.active_hours.start and
           hour < config.settings.active_hours.stop
end

-- 日付変更チェック
function checkDailyReset()
    local current_date = os.date("%Y-%m-%d")
    local saved_date = utils.loadData("last_date")

    if current_date ~= saved_date then
        utils.log("info", "New day detected. Resetting counters...")
        daily_counts.likes = 0
        daily_counts.follows = 0
        daily_counts.unfollows = 0
        errors_count = 0
        utils.saveData("last_date", current_date)
    end
end

-- ================================
-- エラーハンドリング
-- ================================
local status, err = pcall(main)
if not status then
    utils.log("error", "Fatal error: " .. tostring(err))

    if config.safety.auto_restart then
        utils.log("info", "Auto-restarting in 30 seconds...")
        sleep(30)
        restart()
    end
end

-- ================================
-- 終了処理
-- ================================
utils.log("info", "MetaCube stopped")
if config.notifications.on_complete then
    alert("MetaCube: 処理が完了しました")
end